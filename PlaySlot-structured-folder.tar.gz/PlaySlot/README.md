# PlaySlot

PlaySlot is a mobile-first sports venue booking platform for grounds and turfs. It supports consumer bookings and a hidden owner dashboard for managing venues, units, availability, and bookings.

## Stack
- Frontend: React + Vite + Tailwind CSS
- Backend: Node.js + Express
- Database: MongoDB + Mongoose
- Auth: JWT

## Features
- User and owner login/register
- Search venues by location and sport
- Favorites and booking history
- Ground booking: day, night, full
- Tournament booking: multi-day with day/night/full slot mode
- Turf booking: hourly slots
- Booking conflict prevention
- Owner dashboard for venues, units, availability, and bookings
- Dummy payment flow
- Seeder with sample data

## Project structure
- `frontend/`
- `backend/`
- `shared/`
- `setup.sh`
- `.env.example`

## Setup
```bash
cd PlaySlot
bash setup.sh
```

## Manual run
### Backend
```bash
cd backend
cp ../.env.example .env
npm install
npm run seed
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Default API URL
Frontend uses `http://localhost:5000/api`.

## Demo accounts
Seeder creates:
- owner1@playslot.com / password123
- owner2@playslot.com / password123
- user1@playslot.com / password123

## Booking logic summary
- Ground `full` blocks `day` and `night`
- Existing `day` or `night` blocks `full`
- Tournament works on grounds only across a date range with `day`, `night`, or `full`
- Turf booking checks hourly overlap on same date and same turf unit

## Notes
- Maps are placeholder-only in MVP
- Payments are dummy success-only
- Images use local upload support on backend plus sample URLs in seed data

## Hardened in current version
- Frontend form validation for auth, booking, venue, and unit flows
- Owner unit creation UI
- Owner manual availability block UI
- Local image upload endpoint with Multer
- Improved booking summary and hourly availability preview
- Favorites add/remove UI

- Owner unit creation and availability block UI improved
- Booking page upgraded with swipeable date strip, slot pills, sticky mobile CTA, and better touch targets

## Remaining work implemented in this pass
- Reservation hold flow with expiry model
- Improved booking conflict checking using active holds plus existing bookings
- Stripe-ready checkout backend scaffold and frontend payment hooks
- Tournament range calendar UI
- Bookings page now shows active holds and completed bookings

## Notes
- Stripe checkout requires STRIPE_SECRET_KEY and VITE_STRIPE_PUBLISHABLE_KEY to be added before live test flow works
- Reservation hold TTL relies on MongoDB TTL index cleanup and active expiry checks in service logic
