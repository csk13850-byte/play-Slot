import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../services/api';
import { validateVenueForm, validateUnitForm } from '../utils/validators';
import FormError from '../components/ui/FormError';
import SectionCard from '../components/ui/SectionCard';

const initialVenueForm = { name: '', description: '', sportsSupported: 'cricket', city: 'Nashik', area: '', address: '', amenities: 'Floodlights,Parking', images: '' };
const initialUnitForm = { venueId: '', name: '', unitType: 'ground', sportsSupported: 'cricket', dayPrice: '', nightPrice: '', fullPrice: '', hourlyPrice: '', turfStartHour: '06:00', turfEndHour: '23:00' };
const initialBlockForm = { unitId: '', ruleType: 'blocked_date', date: '', slotType: 'day', startTime: '18:00', endTime: '20:00', reason: '' };

export default function OwnerDashboardPage() {
  const [venues, setVenues] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [units, setUnits] = useState([]);
  const [venueForm, setVenueForm] = useState(initialVenueForm);
  const [unitForm, setUnitForm] = useState(initialUnitForm);
  const [blockForm, setBlockForm] = useState(initialBlockForm);
  const [venueErrors, setVenueErrors] = useState({});
  const [unitErrors, setUnitErrors] = useState({});
  const [message, setMessage] = useState('');
  const [uploading, setUploading] = useState(false);

  async function load() {
    const [vRes, bRes] = await Promise.all([apiFetch('/owner/venues'), apiFetch('/owner/bookings')]);
    setVenues(vRes.data);
    setBookings(bRes.data);
    const fullVenueDetails = await Promise.all(vRes.data.map((venue) => apiFetch(`/venues/${venue.slug}`)));
    setUnits(fullVenueDetails.flatMap((res) => res.data.units || []));
  }

  useEffect(() => { load(); }, []);

  const stats = useMemo(() => ({ venues: venues.length, units: units.length, bookings: bookings.length, paid: bookings.filter((b) => b.paymentStatus === 'paid').reduce((sum, b) => sum + (b.totalAmount || 0), 0) }), [venues, units, bookings]);

  async function createVenue(e) {
    e.preventDefault();
    const errors = validateVenueForm(venueForm);
    setVenueErrors(errors);
    if (Object.keys(errors).length) return;
    const payload = {
      name: venueForm.name,
      description: venueForm.description,
      sportsSupported: venueForm.sportsSupported.split(',').map((x) => x.trim()).filter(Boolean),
      location: { city: venueForm.city, area: venueForm.area, address: venueForm.address },
      amenities: venueForm.amenities.split(',').map((x) => x.trim()).filter(Boolean),
      images: venueForm.images ? venueForm.images.split(',').map((x) => x.trim()).filter(Boolean) : []
    };
    const res = await apiFetch('/owner/venues', { method: 'POST', body: JSON.stringify(payload) });
    setMessage(res.message);
    setVenueForm(initialVenueForm);
    load();
  }

  async function createUnit(e) {
    e.preventDefault();
    const errors = validateUnitForm(unitForm);
    setUnitErrors(errors);
    if (Object.keys(errors).length) return;
    const payload = {
      venueId: unitForm.venueId,
      name: unitForm.name,
      unitType: unitForm.unitType,
      sportsSupported: unitForm.sportsSupported.split(',').map((x) => x.trim()).filter(Boolean),
      pricing: unitForm.unitType === 'ground' ? { day: Number(unitForm.dayPrice), night: Number(unitForm.nightPrice), full: Number(unitForm.fullPrice) } : { hourly: Number(unitForm.hourlyPrice) },
      slotConfig: unitForm.unitType === 'ground' ? { dayStart: '06:00', dayEnd: '18:00', slotDurationMinutes: 60 } : { turfStartHour: unitForm.turfStartHour, turfEndHour: unitForm.turfEndHour, slotDurationMinutes: 60 }
    };
    const res = await apiFetch('/owner/units', { method: 'POST', body: JSON.stringify(payload) });
    setMessage(res.message);
    setUnitForm(initialUnitForm);
    load();
  }

  async function createBlock(e) {
    e.preventDefault();
    const payload = {
      unitId: blockForm.unitId,
      ruleType: blockForm.ruleType,
      date: blockForm.date,
      slotType: blockForm.ruleType === 'blocked_slot' ? blockForm.slotType : undefined,
      startTime: blockForm.ruleType === 'blocked_slot' && blockForm.slotType === 'hourly' ? blockForm.startTime : undefined,
      endTime: blockForm.ruleType === 'blocked_slot' && blockForm.slotType === 'hourly' ? blockForm.endTime : undefined,
      reason: blockForm.reason
    };
    const res = await apiFetch('/owner/availability/block', { method: 'POST', body: JSON.stringify(payload) });
    setMessage(res.message);
    setBlockForm(initialBlockForm);
  }

  async function handleUpload(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    const formData = new FormData();
    files.forEach((file) => formData.append('images', file));
    const token = localStorage.getItem('playslot_token');
    const res = await fetch('http://localhost:5000/api/uploads/images', { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: formData });
    const data = await res.json();
    setUploading(false);
    if (!res.ok) return setMessage(data.message || 'Upload failed');
    setVenueForm((prev) => ({ ...prev, images: [...(prev.images ? prev.images.split(',').map((x) => x.trim()).filter(Boolean) : []), ...data.data.files.map((file) => `http://localhost:5000${file}`)].join(',') }));
    setMessage('Images uploaded and added to form');
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        <div className="card"><p className="text-sm text-slate-400">Venues</p><p className="mt-2 text-3xl font-bold">{stats.venues}</p></div>
        <div className="card"><p className="text-sm text-slate-400">Units</p><p className="mt-2 text-3xl font-bold">{stats.units}</p></div>
        <div className="card"><p className="text-sm text-slate-400">Bookings</p><p className="mt-2 text-3xl font-bold">{stats.bookings}</p></div>
        <div className="card"><p className="text-sm text-slate-400">Paid revenue</p><p className="mt-2 text-3xl font-bold">₹{stats.paid}</p></div>
      </div>
      {message && <div className="rounded-2xl border border-brand-500/20 bg-brand-500/10 p-4 text-sm text-brand-300">{message}</div>}
      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="Create venue" subtitle="Add a new sports venue with sports, amenities, and gallery.">
          <form onSubmit={createVenue} className="space-y-4">
            <div><label className="label">Venue name</label><input className="input" value={venueForm.name} onChange={(e) => setVenueForm({ ...venueForm, name: e.target.value })} /><FormError message={venueErrors.name} /></div>
            <div><label className="label">Description</label><textarea className="input min-h-28" value={venueForm.description} onChange={(e) => setVenueForm({ ...venueForm, description: e.target.value })} /><FormError message={venueErrors.description} /></div>
            <div className="grid gap-4 md:grid-cols-2">
              <div><label className="label">Sports</label><input className="input" value={venueForm.sportsSupported} onChange={(e) => setVenueForm({ ...venueForm, sportsSupported: e.target.value })} /><FormError message={venueErrors.sportsSupported} /></div>
              <div><label className="label">City</label><input className="input" value={venueForm.city} onChange={(e) => setVenueForm({ ...venueForm, city: e.target.value })} /><FormError message={venueErrors.city} /></div>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div><label className="label">Area</label><input className="input" value={venueForm.area} onChange={(e) => setVenueForm({ ...venueForm, area: e.target.value })} /></div>
              <div><label className="label">Address</label><input className="input" value={venueForm.address} onChange={(e) => setVenueForm({ ...venueForm, address: e.target.value })} /></div>
            </div>
            <div><label className="label">Amenities</label><input className="input" value={venueForm.amenities} onChange={(e) => setVenueForm({ ...venueForm, amenities: e.target.value })} /></div>
            <div><label className="label">Image URLs</label><input className="input" value={venueForm.images} onChange={(e) => setVenueForm({ ...venueForm, images: e.target.value })} /></div>
            <div><label className="label">Upload images</label><input type="file" multiple accept="image/*" className="input" onChange={handleUpload} /><p className="mt-2 text-sm text-slate-400">{uploading ? 'Uploading images...' : 'Upload JPG, PNG, or WEBP files up to 5MB each'}</p></div>
            <button className="btn-primary w-full">Create venue</button>
          </form>
        </SectionCard>
        <SectionCard title="Create unit" subtitle="Add ground or turf inventory under a venue.">
          <form onSubmit={createUnit} className="space-y-4">
            <div><label className="label">Venue</label><select className="input" value={unitForm.venueId} onChange={(e) => setUnitForm({ ...unitForm, venueId: e.target.value })}><option value="">Select venue</option>{venues.map((v) => <option key={v._id} value={v._id}>{v.name}</option>)}</select><FormError message={unitErrors.venueId} /></div>
            <div className="grid gap-4 md:grid-cols-2">
              <div><label className="label">Unit name</label><input className="input" value={unitForm.name} onChange={(e) => setUnitForm({ ...unitForm, name: e.target.value })} /><FormError message={unitErrors.name} /></div>
              <div><label className="label">Unit type</label><select className="input" value={unitForm.unitType} onChange={(e) => setUnitForm({ ...unitForm, unitType: e.target.value })}><option value="ground">Ground</option><option value="turf">Turf</option></select></div>
            </div>
            <div><label className="label">Sports</label><input className="input" value={unitForm.sportsSupported} onChange={(e) => setUnitForm({ ...unitForm, sportsSupported: e.target.value })} /><FormError message={unitErrors.sportsSupported} /></div>
            {unitForm.unitType === 'ground' ? <div className="grid gap-4 md:grid-cols-3"><div><label className="label">Day price</label><input type="number" className="input" value={unitForm.dayPrice} onChange={(e) => setUnitForm({ ...unitForm, dayPrice: e.target.value })} /><FormError message={unitErrors.dayPrice} /></div><div><label className="label">Night price</label><input type="number" className="input" value={unitForm.nightPrice} onChange={(e) => setUnitForm({ ...unitForm, nightPrice: e.target.value })} /><FormError message={unitErrors.nightPrice} /></div><div><label className="label">Full price</label><input type="number" className="input" value={unitForm.fullPrice} onChange={(e) => setUnitForm({ ...unitForm, fullPrice: e.target.value })} /><FormError message={unitErrors.fullPrice} /></div></div> : <div className="grid gap-4 md:grid-cols-3"><div><label className="label">Hourly price</label><input type="number" className="input" value={unitForm.hourlyPrice} onChange={(e) => setUnitForm({ ...unitForm, hourlyPrice: e.target.value })} /><FormError message={unitErrors.hourlyPrice} /></div><div><label className="label">Start hour</label><input type="time" className="input" value={unitForm.turfStartHour} onChange={(e) => setUnitForm({ ...unitForm, turfStartHour: e.target.value })} /><FormError message={unitErrors.turfStartHour} /></div><div><label className="label">End hour</label><input type="time" className="input" value={unitForm.turfEndHour} onChange={(e) => setUnitForm({ ...unitForm, turfEndHour: e.target.value })} /><FormError message={unitErrors.turfEndHour} /></div></div>}
            <button className="btn-primary w-full">Create unit</button>
          </form>
        </SectionCard>
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="Availability block" subtitle="Block dates or slot windows for a unit.">
          <form onSubmit={createBlock} className="space-y-4">
            <div><label className="label">Unit</label><select className="input" value={blockForm.unitId} onChange={(e) => setBlockForm({ ...blockForm, unitId: e.target.value })}><option value="">Select unit</option>{units.map((u) => <option key={u._id} value={u._id}>{u.name} ({u.unitType})</option>)}</select></div>
            <div className="grid gap-4 md:grid-cols-2"><div><label className="label">Rule type</label><select className="input" value={blockForm.ruleType} onChange={(e) => setBlockForm({ ...blockForm, ruleType: e.target.value })}><option value="blocked_date">Blocked date</option><option value="blocked_slot">Blocked slot</option></select></div><div><label className="label">Date</label><input type="date" className="input" value={blockForm.date} onChange={(e) => setBlockForm({ ...blockForm, date: e.target.value })} /></div></div>
            {blockForm.ruleType === 'blocked_slot' && <><div><label className="label">Slot type</label><select className="input" value={blockForm.slotType} onChange={(e) => setBlockForm({ ...blockForm, slotType: e.target.value })}><option value="day">Day</option><option value="night">Night</option><option value="full">Full</option><option value="hourly">Hourly</option></select></div>{blockForm.slotType === 'hourly' && <div className="grid gap-4 md:grid-cols-2"><div><label className="label">Start time</label><input type="time" className="input" value={blockForm.startTime} onChange={(e) => setBlockForm({ ...blockForm, startTime: e.target.value })} /></div><div><label className="label">End time</label><input type="time" className="input" value={blockForm.endTime} onChange={(e) => setBlockForm({ ...blockForm, endTime: e.target.value })} /></div></div>}</>}
            <div><label className="label">Reason</label><input className="input" value={blockForm.reason} onChange={(e) => setBlockForm({ ...blockForm, reason: e.target.value })} /></div>
            <button className="btn-primary w-full">Save block</button>
          </form>
        </SectionCard>
        <SectionCard title="Owner bookings" subtitle="Track current reservations across your venues.">
          <div className="space-y-3">{bookings.length === 0 ? <p className="text-slate-400">No bookings yet.</p> : bookings.map((booking) => <div key={booking._id} className="rounded-2xl border border-slate-800 p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-semibold">{booking.venueId?.name} · {booking.unitId?.name}</p><p className="text-sm text-slate-400">{booking.bookingType} · {booking.slotType}</p><p className="text-sm text-slate-500">{booking.date || `${booking.startDate} to ${booking.endDate}`}</p></div><span className="rounded-full bg-brand-500/15 px-3 py-1 text-sm text-brand-400">₹{booking.totalAmount}</span></div></div>)}</div>
        </SectionCard>
      </div>
    </div>
  );
}
