import { Navigate } from 'react-router-dom';
import { useAuth } from '../app/AuthContext';

export default function ProtectedRoute({ children, ownerOnly = false }) {
  const { user, loading } = useAuth();
  if (loading) return <p className="text-slate-400">Loading...</p>;
  if (!user) return <Navigate to="/login" replace />;
  if (ownerOnly && user.role !== 'owner') return <Navigate to="/" replace />;
  return children;
}
