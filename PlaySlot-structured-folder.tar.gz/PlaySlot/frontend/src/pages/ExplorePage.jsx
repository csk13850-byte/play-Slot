import { useEffect, useState } from 'react';
import { apiFetch } from '../services/api';
import VenueCard from '../components/cards/VenueCard';

export default function ExplorePage() {
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState('');
  const [sport, setSport] = useState('');

  async function load() {
    setLoading(true);
    const params = new URLSearchParams();
    if (location) params.set('location', location);
    if (sport) params.set('sport', sport);
    const res = await apiFetch(`/venues?${params.toString()}`);
    setVenues(res.data.items);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6">
      <div className="grid gap-3 md:grid-cols-4">
        <input className="input md:col-span-2" placeholder="Search by location" value={location} onChange={(e) => setLocation(e.target.value)} />
        <select className="input" value={sport} onChange={(e) => setSport(e.target.value)}>
          <option value="">All sports</option>
          <option value="cricket">Cricket</option>
          <option value="football">Football</option>
          <option value="badminton">Badminton</option>
          <option value="pickleball">Pickleball</option>
        </select>
        <button className="btn-primary" onClick={load}>Search</button>
      </div>
      {loading ? <p className="text-slate-400">Loading venues...</p> : (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {venues.map((venue) => <VenueCard key={venue._id} venue={venue} />)}
        </div>
      )}
    </div>
  );
}
