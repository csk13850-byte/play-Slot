import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../app/AuthContext';
import { validateAuthForm } from '../utils/validators';
import FormError from '../components/ui/FormError';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [errors, setErrors] = useState({});

  async function handleSubmit(e) {
    e.preventDefault();
    const nextErrors = validateAuthForm(form, 'login');
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    try {
      await login(form.email, form.password);
      navigate('/');
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-md card space-y-4">
      <h1 className="text-2xl font-bold">Login</h1>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <div><label className="label">Email</label><input className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /><FormError message={errors.email} /></div>
      <div><label className="label">Password</label><input type="password" className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /><FormError message={errors.password} /></div>
      <button className="btn-primary w-full">Login</button>
      <p className="text-sm text-slate-400">Demo: owner1@playslot.com / password123</p>
    </form>
  );
}
