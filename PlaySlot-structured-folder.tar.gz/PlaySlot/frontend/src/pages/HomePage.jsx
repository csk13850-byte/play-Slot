import { Link } from 'react-router-dom';

export default function HomePage() {
  return (
    <div className="space-y-8">
      <section className="grid gap-6 rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 to-slate-950 p-6 md:grid-cols-2 md:p-10">
        <div>
          <p className="mb-3 inline-flex rounded-full bg-brand-500/10 px-3 py-1 text-sm text-brand-400">Sports booking marketplace</p>
          <h1 className="text-4xl font-bold leading-tight md:text-5xl">Book cricket grounds, turfs, and tournament venues in one flow.</h1>
          <p className="mt-4 max-w-xl text-slate-400">PlaySlot helps players book by hour, by match slot, or across tournament date ranges while owners manage listings, availability, and bookings from one dashboard.</p>
          <div className="mt-6 flex gap-3">
            <Link to="/explore" className="btn-primary">Explore venues</Link>
            <Link to="/register" className="btn-secondary">Create account</Link>
          </div>
        </div>
        <div className="card flex flex-col justify-center gap-4">
          <div className="rounded-2xl bg-slate-800 p-4">
            <p className="text-sm text-slate-400">Ground Booking</p>
            <p className="mt-1 text-2xl font-semibold">Day · Night · Full</p>
          </div>
          <div className="rounded-2xl bg-slate-800 p-4">
            <p className="text-sm text-slate-400">Tournament Booking</p>
            <p className="mt-1 text-2xl font-semibold">Multi-day slot blocking</p>
          </div>
          <div className="rounded-2xl bg-slate-800 p-4">
            <p className="text-sm text-slate-400">Turf Booking</p>
            <p className="mt-1 text-2xl font-semibold">Hourly booking engine</p>
          </div>
        </div>
      </section>
    </div>
  );
}
