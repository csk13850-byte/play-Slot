import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../app/AuthContext';
import { validateAuthForm } from '../utils/validators';
import FormError from '../components/ui/FormError';

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'user' });
  const [error, setError] = useState('');
  const [errors, setErrors] = useState({});

  async function handleSubmit(e) {
    e.preventDefault();
    const nextErrors = validateAuthForm(form, 'register');
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    try {
      await register(form);
      navigate('/');
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-md card space-y-4">
      <h1 className="text-2xl font-bold">Register</h1>
      {error && <p className="text-sm text-red-400">{error}</p>}
      <div><label className="label">Name</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /><FormError message={errors.name} /></div>
      <div><label className="label">Email</label><input className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /><FormError message={errors.email} /></div>
      <div><label className="label">Password</label><input type="password" className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /><FormError message={errors.password} /></div>
      <div><label className="label">Role</label><select className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}><option value="user">User</option><option value="owner">Owner</option></select></div>
      <button className="btn-primary w-full">Create account</button>
    </form>
  );
}
