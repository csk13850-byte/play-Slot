import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { apiFetch } from '../services/api';
import { useAuth } from '../app/AuthContext';

export default function VenueDetailPage() {
  const { slug } = useParams();
  const { user } = useAuth();
  const [venue, setVenue] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    apiFetch(`/venues/${slug}`).then((res) => setVenue(res.data)).finally(() => setLoading(false));
  }, [slug]);

  async function addFavorite() {
    try {
      await apiFetch(`/users/me/favorites/${venue._id}`, { method: 'POST' });
      setMessage('Added to favorites');
    } catch (e) {
      setMessage(e.message);
    }
  }

  if (loading) return <p className="text-slate-400">Loading venue...</p>;
  if (!venue) return <p>Venue not found</p>;

  return (
    <div className="space-y-6">
      <img src={venue.images?.[0]} alt={venue.name} className="h-72 w-full rounded-3xl object-cover" />
      <div className="grid gap-6 md:grid-cols-[2fr_1fr]">
        <div className="space-y-5">
          <div className="card">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold">{venue.name}</h1>
                <p className="mt-2 text-slate-400">{venue.description}</p>
                <p className="mt-4 text-sm text-slate-400">{venue.location?.address}, {venue.location?.area}, {venue.location?.city}</p>
              </div>
              {user && <button className="btn-secondary" onClick={addFavorite}>Add to favorites</button>}
            </div>
            {message && <p className="mt-3 text-sm text-brand-400">{message}</p>}
          </div>
          <div className="card">
            <h2 className="text-xl font-semibold">Units</h2>
            <div className="mt-4 space-y-3">
              {venue.units?.map((unit) => (
                <div key={unit._id} className="rounded-2xl border border-slate-800 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <h3 className="font-semibold">{unit.name}</h3>
                      <p className="text-sm text-slate-400">{unit.unitType} · {unit.sportsSupported?.join(', ')}</p>
                      <p className="mt-1 text-sm text-slate-500">{unit.unitType === 'ground' ? `Day ₹${unit.pricing?.day} · Night ₹${unit.pricing?.night} · Full ₹${unit.pricing?.full}` : `Hourly ₹${unit.pricing?.hourly}`}</p>
                    </div>
                    <Link to={`/book/${unit._id}`} className="btn-primary">Book now</Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="space-y-5">
          <div className="card h-fit">
            <h3 className="text-lg font-semibold">Amenities</h3>
            <div className="mt-3 flex flex-wrap gap-2">
              {venue.amenities?.map((item) => <span key={item} className="rounded-full bg-slate-800 px-3 py-1 text-sm text-slate-300">{item}</span>)}
            </div>
          </div>
          <div className="card h-fit">
            <h3 className="text-lg font-semibold">Map placeholder</h3>
            <div className="mt-3 rounded-2xl border border-dashed border-slate-700 bg-slate-900 p-6 text-sm text-slate-400">Google Maps integration placeholder for {venue.location?.area}, {venue.location?.city}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
