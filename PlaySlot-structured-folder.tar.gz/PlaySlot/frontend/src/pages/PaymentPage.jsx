import { useEffect, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { apiFetch } from '../services/api';

export default function PaymentPage() {
  const { bookingId } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('Choose a payment method');

  useEffect(() => {
    async function confirmStripeIfNeeded() {
      const holdId = params.get('holdId');
      const sessionId = params.get('session_id');
      if (!holdId || !sessionId) return;
      setLoading(true);
      try {
        await apiFetch('/payments/stripe/confirm', { method: 'POST', body: JSON.stringify({ holdId, sessionId }) });
        setMessage('Stripe test payment confirmed. Booking completed.');
      } catch (e) {
        setMessage(e.message);
      } finally {
        setLoading(false);
      }
    }
    confirmStripeIfNeeded();
  }, [params]);

  async function payDummy() {
    setLoading(true);
    try {
      await apiFetch(`/payments/dummy/${bookingId}`, { method: 'POST' });
      setMessage('Dummy payment successful');
      navigate('/my-bookings');
    } catch (e) {
      setMessage(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl card space-y-4">
      <h1 className="text-2xl font-bold">Payment</h1>
      <p className="text-slate-400">{message}</p>
      <button onClick={payDummy} disabled={loading || !bookingId} className="btn-primary w-full">{loading ? 'Processing...' : 'Pay with dummy checkout'}</button>
      <p className="text-sm text-slate-500">Stripe test-mode support is scaffolded in backend routes and environment variables. Create a hold first, then redirect to Stripe checkout when keys are added.</p>
    </div>
  );
}
