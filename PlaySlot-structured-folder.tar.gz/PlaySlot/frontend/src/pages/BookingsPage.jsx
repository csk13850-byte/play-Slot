import { useEffect, useState } from 'react';
import { apiFetch } from '../services/api';

export default function BookingsPage() {
  const [bookings, setBookings] = useState([]);
  const [holds, setHolds] = useState([]);

  useEffect(() => {
    apiFetch('/bookings/my').then((res) => {
      setBookings(res.data.bookings || []);
      setHolds(res.data.holds || []);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">My bookings</h1>
        <p className="text-slate-400">Confirmed, pending, and active reservation holds.</p>
      </div>

      <div className="space-y-3">
        <h2 className="text-lg font-semibold">Active holds</h2>
        {holds.length === 0 ? <p className="text-slate-500">No active holds.</p> : holds.map((hold) => (
          <div key={hold._id} className="card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{hold.venueId?.name} · {hold.unitId?.name}</p>
                <p className="text-sm text-slate-400">Expires at {new Date(hold.expiresAt).toLocaleString('en-IN')}</p>
              </div>
              <span className="rounded-full bg-yellow-500/15 px-3 py-1 text-sm text-yellow-300">Hold</span>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="text-lg font-semibold">Bookings</h2>
        {bookings.length === 0 ? <p className="text-slate-500">No bookings yet.</p> : bookings.map((booking) => (
          <div key={booking._id} className="card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{booking.venueId?.name} · {booking.unitId?.name}</p>
                <p className="text-sm text-slate-400">{booking.bookingType} · {booking.slotType}</p>
                <p className="text-sm text-slate-500">{booking.date || `${booking.startDate} to ${booking.endDate}`}</p>
              </div>
              <span className="rounded-full bg-brand-500/15 px-3 py-1 text-sm text-brand-300">{booking.paymentStatus}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
