import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiFetch } from '../services/api';

export default function FavoritesPage() {
  const [favorites, setFavorites] = useState([]);
  async function load() {
    const res = await apiFetch('/users/me/favorites');
    setFavorites(res.data);
  }
  useEffect(() => { load(); }, []);
  async function removeFavorite(venueId) {
    await apiFetch(`/users/me/favorites/${venueId}`, { method: 'DELETE' });
    load();
  }
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Favorite venues</h1>
      {favorites.length === 0 ? <p className="text-slate-400">No favorites yet.</p> : favorites.map((item) => (
        <div key={item._id} className="card flex items-center justify-between gap-4">
          <div>
            <h3 className="font-semibold">{item.venueId?.name}</h3>
            <p className="text-sm text-slate-400">{item.venueId?.location?.city}</p>
          </div>
          <div className="flex gap-2">
            <Link className="btn-secondary" to={`/venues/${item.venueId?.slug}`}>View</Link>
            <button className="btn-primary" onClick={() => removeFavorite(item.venueId?._id)}>Remove</button>
          </div>
        </div>
      ))}
    </div>
  );
}
