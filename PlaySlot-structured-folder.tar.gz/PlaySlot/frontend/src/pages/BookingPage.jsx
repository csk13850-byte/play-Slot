import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { apiFetch } from '../services/api';
import { validateBookingForm } from '../utils/validators';
import FormError from '../components/ui/FormError';
import SectionCard from '../components/ui/SectionCard';
import CalendarStrip from '../components/booking/CalendarStrip';
import SlotPills from '../components/booking/SlotPills';
import RangeCalendar from '../components/booking/RangeCalendar';

export default function BookingPage() {
  const { unitId } = useParams();
  const navigate = useNavigate();
  const [unit, setUnit] = useState(null);
  const [availability, setAvailability] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ bookingType: 'ground', slotType: 'day', date: '', startDate: '', endDate: '', startTime: '18:00', hours: 1, contactName: '', contactPhone: '' });
  const [quote, setQuote] = useState(null);
  const [hold, setHold] = useState(null);
  const [error, setError] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    async function loadUnit() {
      setLoading(true);
      const venueRes = await apiFetch('/venues');
      for (const venue of venueRes.data.items) {
        try {
          const detail = await apiFetch(`/venues/${venue.slug}`);
          const found = detail.data.units.find((u) => u._id === unitId);
          if (found) {
            setUnit(found);
            setForm((prev) => ({ ...prev, bookingType: found.unitType === 'turf' ? 'turf' : 'ground', slotType: found.unitType === 'turf' ? 'hourly' : 'day' }));
            break;
          }
        } catch (_e) {}
      }
      setLoading(false);
    }
    loadUnit();
  }, [unitId]);

  useEffect(() => {
    if (!unit || !form.date || unit.unitType !== 'turf') return;
    apiFetch(`/venues/availability/by-unit?unitId=${unitId}&date=${form.date}`).then((res) => setAvailability(res.data.hourlySlots || [])).catch(() => setAvailability([]));
  }, [unit, form.date, unitId]);

  const isTournament = form.bookingType === 'tournament';
  const isTurf = unit?.unitType === 'turf';
  const selectedSummary = useMemo(() => {
    if (!unit) return null;
    if (isTournament) return `${form.slotType} tournament from ${form.startDate || '—'} to ${form.endDate || '—'}`;
    if (isTurf) return `${form.date || '—'} at ${form.startTime || '—'} for ${form.hours || 1} hour(s)`;
    return `${form.slotType} slot on ${form.date || '—'}`;
  }, [unit, isTournament, isTurf, form]);

  function handleRangeSelect(date) {
    if (!form.startDate || (form.startDate && form.endDate)) {
      setForm({ ...form, startDate: date, endDate: '' });
      return;
    }
    if (date < form.startDate) {
      setForm({ ...form, startDate: date, endDate: form.startDate });
      return;
    }
    setForm({ ...form, endDate: date });
  }

  async function getQuote() {
    setError('');
    const nextErrors = validateBookingForm(form, unit?.unitType);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    try {
      const res = await apiFetch('/bookings/quote', { method: 'POST', body: JSON.stringify({ unitId, ...form, hours: Number(form.hours) }) });
      setQuote(res.data);
    } catch (e) {
      setQuote(null);
      setError(e.message);
    }
  }

  async function createHold() {
    setError('');
    const nextErrors = validateBookingForm(form, unit?.unitType);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    try {
      const res = await apiFetch('/bookings/hold', { method: 'POST', body: JSON.stringify({ unitId, ...form, hours: Number(form.hours) }) });
      setHold(res.data);
    } catch (e) {
      setError(e.message);
    }
  }

  async function continueDummy() {
    try {
      const res = await apiFetch('/bookings', { method: 'POST', body: JSON.stringify({ unitId, ...form, hours: Number(form.hours) }) });
      navigate(`/payment/${res.data._id}`);
    } catch (e) {
      setError(e.message);
    }
  }

  async function continueStripe() {
    try {
      const activeHold = hold || (await apiFetch('/bookings/hold', { method: 'POST', body: JSON.stringify({ unitId, ...form, hours: Number(form.hours) }) })).data;
      const res = await apiFetch('/payments/stripe/checkout', { method: 'POST', body: JSON.stringify({ holdId: activeHold._id }) });
      window.location.href = res.data.url;
    } catch (e) {
      setError(e.message);
    }
  }

  if (loading) return <p className="text-slate-400">Loading booking flow...</p>;
  if (!unit) return <p className="text-slate-400">Unit not found.</p>;

  return (
    <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
      <SectionCard title={`Book ${unit.name}`} subtitle="Choose booking type, date, slot, and contact details.">
        <div className="space-y-5">
          {!isTurf && (
            <div>
              <label className="label">Booking type</label>
              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setForm({ ...form, bookingType: 'ground', slotType: 'day' })} className={`rounded-2xl border px-4 py-3 text-sm font-medium ${form.bookingType === 'ground' ? 'border-brand-500 bg-brand-500/15 text-brand-300' : 'border-slate-800 bg-slate-900 text-slate-300'}`}>Single match</button>
                <button type="button" onClick={() => setForm({ ...form, bookingType: 'tournament', slotType: 'full' })} className={`rounded-2xl border px-4 py-3 text-sm font-medium ${form.bookingType === 'tournament' ? 'border-brand-500 bg-brand-500/15 text-brand-300' : 'border-slate-800 bg-slate-900 text-slate-300'}`}>Tournament</button>
              </div>
            </div>
          )}

          {!isTournament ? (
            <div>
              <label className="label">Pick date</label>
              <CalendarStrip selectedDate={form.date} blockedDates={[]} onSelect={(date) => setForm({ ...form, date })} />
              <div className="mt-3"><input type="date" className="input" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /><FormError message={errors.date} /></div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="label">Tournament date range</label>
                <RangeCalendar startDate={form.startDate} endDate={form.endDate} onSelect={handleRangeSelect} />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div><label className="label">Start date</label><input type="date" className="input" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /><FormError message={errors.startDate} /></div>
                <div><label className="label">End date</label><input type="date" className="input" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /><FormError message={errors.endDate} /></div>
              </div>
            </div>
          )}

          <div>
            <label className="label">Slot type</label>
            <SlotPills value={form.slotType} onChange={(slotType) => setForm({ ...form, slotType })} options={isTurf ? [{ value: 'hourly', label: 'Hourly', caption: 'Flexible turf slots' }] : [{ value: 'day', label: 'Day', caption: 'Morning to evening' }, { value: 'night', label: 'Night', caption: 'Floodlight slot' }, { value: 'full', label: 'Full', caption: 'Whole unit block' }]} />
          </div>

          {isTurf && (
            <div className="space-y-4 rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
              <div className="grid gap-4 grid-cols-2">
                <div><label className="label">Start time</label><input type="time" className="input" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} /><FormError message={errors.startTime} /></div>
                <div><label className="label">Hours</label><input type="number" min="1" max="8" className="input" value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })} /><FormError message={errors.hours} /></div>
              </div>
              {availability.length > 0 && (
                <div>
                  <label className="label">Tap a start slot</label>
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {availability.map((slot) => (
                      <button key={slot.startTime} type="button" onClick={() => slot.available && setForm({ ...form, startTime: slot.startTime })} className={`rounded-2xl border px-3 py-3 text-sm ${slot.available ? form.startTime === slot.startTime ? 'border-brand-500 bg-brand-500/15 text-brand-300' : 'border-slate-700 bg-slate-950 text-slate-200' : 'border-slate-800 bg-slate-900 text-slate-600'}`}>{slot.startTime} - {slot.endTime}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
            <p className="text-sm font-medium text-slate-300">Contact details</p>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div><label className="label">Contact name</label><input className="input" value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} /><FormError message={errors.contactName} /></div>
              <div><label className="label">Contact phone</label><input className="input" value={form.contactPhone} onChange={(e) => setForm({ ...form, contactPhone: e.target.value })} /><FormError message={errors.contactPhone} /></div>
            </div>
          </div>

          {error && <div className="rounded-2xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-300">{error}</div>}
          {hold && <div className="rounded-2xl border border-yellow-500/20 bg-yellow-500/10 p-4 text-sm text-yellow-200">Hold active until {new Date(hold.expiresAt).toLocaleTimeString('en-IN')}</div>}
          <div className="sticky bottom-3 z-10 flex flex-col gap-2 rounded-3xl border border-slate-800 bg-slate-950/95 p-3 backdrop-blur lg:static lg:border-0 lg:bg-transparent lg:p-0">
            <div className="grid grid-cols-2 gap-2"><button className="btn-secondary" type="button" onClick={getQuote}>Get quote</button><button className="btn-secondary" type="button" onClick={createHold}>Hold for 10 min</button></div>
            <div className="grid grid-cols-2 gap-2"><button className="btn-primary" type="button" onClick={continueDummy}>Dummy pay</button><button className="btn-primary" type="button" onClick={continueStripe}>Stripe checkout</button></div>
          </div>
        </div>
      </SectionCard>

      <div className="space-y-4">
        <SectionCard title="Booking summary" subtitle="Review your selection before payment.">
          <div className="space-y-4">
            <div className="rounded-2xl bg-slate-800 p-4"><p className="text-sm text-slate-400">Unit</p><p className="mt-1 font-semibold">{unit.name}</p><p className="text-sm text-slate-500">{unit.unitType} · {unit.sportsSupported?.join(', ')}</p></div>
            <div className="rounded-2xl bg-slate-800 p-4"><p className="text-sm text-slate-400">Selection</p><p className="mt-1 font-semibold">{selectedSummary}</p></div>
            {quote ? <div className="rounded-2xl bg-brand-500/10 p-4"><p className="text-sm text-brand-300">Estimated amount</p><p className="mt-1 text-3xl font-bold text-white">₹{quote.totalAmount}</p></div> : <p className="text-sm text-slate-400">Generate a quote to confirm pricing and availability.</p>}
          </div>
        </SectionCard>
        <SectionCard title="Quick tips" subtitle="Safer reservation flow enabled.">
          <ul className="space-y-3 text-sm text-slate-300">
            <li>Create a hold first if you want to reserve the slot before payment.</li>
            <li>Dummy payment works immediately for local MVP testing.</li>
            <li>Stripe test checkout becomes active after adding Stripe keys in environment variables.</li>
          </ul>
        </SectionCard>
      </div>
    </div>
  );
}
