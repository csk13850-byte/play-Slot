export function validateAuthForm(form, mode = 'login') {
  const errors = {};
  if (mode === 'register' && !form.name?.trim()) errors.name = 'Name is required';
  if (!form.email?.trim()) errors.email = 'Email is required';
  else if (!/^\S+@\S+\.\S+$/.test(form.email)) errors.email = 'Enter a valid email';
  if (!form.password?.trim()) errors.password = 'Password is required';
  else if (form.password.length < 6) errors.password = 'Password must be at least 6 characters';
  return errors;
}

export function validateVenueForm(form) {
  const errors = {};
  if (!form.name?.trim()) errors.name = 'Venue name is required';
  if (!form.description?.trim() || form.description.trim().length < 20) errors.description = 'Description must be at least 20 characters';
  if (!form.city?.trim()) errors.city = 'City is required';
  if (!form.sportsSupported?.trim()) errors.sportsSupported = 'Add at least one sport';
  return errors;
}

export function validateUnitForm(form) {
  const errors = {};
  if (!form.venueId) errors.venueId = 'Select a venue';
  if (!form.name?.trim()) errors.name = 'Unit name is required';
  if (!form.unitType) errors.unitType = 'Unit type is required';
  if (!form.sportsSupported?.trim()) errors.sportsSupported = 'Add at least one sport';
  if (form.unitType === 'ground') {
    if (!form.dayPrice) errors.dayPrice = 'Day price required';
    if (!form.nightPrice) errors.nightPrice = 'Night price required';
    if (!form.fullPrice) errors.fullPrice = 'Full price required';
  }
  if (form.unitType === 'turf') {
    if (!form.hourlyPrice) errors.hourlyPrice = 'Hourly price required';
    if (!form.turfStartHour) errors.turfStartHour = 'Start hour required';
    if (!form.turfEndHour) errors.turfEndHour = 'End hour required';
  }
  return errors;
}

export function validateBookingForm(form, unitType) {
  const errors = {};
  if (!form.contactName?.trim()) errors.contactName = 'Contact name is required';
  if (!form.contactPhone?.trim()) errors.contactPhone = 'Contact phone is required';
  if (form.bookingType === 'tournament') {
    if (!form.startDate) errors.startDate = 'Start date is required';
    if (!form.endDate) errors.endDate = 'End date is required';
    if (form.startDate && form.endDate && form.startDate > form.endDate) errors.endDate = 'End date must be after start date';
  } else {
    if (!form.date) errors.date = 'Date is required';
  }
  if (unitType === 'turf') {
    if (!form.startTime) errors.startTime = 'Start time is required';
    if (!form.hours || Number(form.hours) < 1) errors.hours = 'Hours must be at least 1';
  }
  return errors;
}
