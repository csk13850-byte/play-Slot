import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { apiFetch } from '../services/api';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('playslot_token');
    if (!token) return setLoading(false);
    apiFetch('/auth/me').then((res) => setUser(res.data)).catch(() => localStorage.removeItem('playslot_token')).finally(() => setLoading(false));
  }, []);

  const value = useMemo(() => ({
    user,
    loading,
    async login(email, password) {
      const res = await apiFetch('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      localStorage.setItem('playslot_token', res.data.token);
      setUser(res.data.user);
    },
    async register(payload) {
      const res = await apiFetch('/auth/register', { method: 'POST', body: JSON.stringify(payload) });
      localStorage.setItem('playslot_token', res.data.token);
      setUser(res.data.user);
    },
    logout() {
      localStorage.removeItem('playslot_token');
      setUser(null);
    }
  }), [user, loading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
