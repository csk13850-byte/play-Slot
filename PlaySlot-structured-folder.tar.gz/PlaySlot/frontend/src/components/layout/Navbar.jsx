import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../app/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 text-white">
        <Link to="/" className="text-xl font-bold text-brand-500">PlaySlot</Link>
        <nav className="flex items-center gap-3 text-sm">
          <Link to="/explore">Explore</Link>
          {user && <Link to="/favorites">Favorites</Link>}
          {user && <Link to="/bookings">Bookings</Link>}
          {user?.role === 'owner' && <Link to="/owner">Owner</Link>}
          {!user ? (
            <>
              <Link className="btn-secondary" to="/login">Login</Link>
              <Link className="btn-primary" to="/register">Register</Link>
            </>
          ) : (
            <button className="btn-secondary" onClick={() => { logout(); navigate('/'); }}>Logout</button>
          )}
        </nav>
      </div>
    </header>
  );
}
