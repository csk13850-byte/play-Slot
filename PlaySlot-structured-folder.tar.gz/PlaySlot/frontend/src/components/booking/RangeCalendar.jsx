import { useMemo } from 'react';

function iso(date) {
  return date.toISOString().slice(0, 10);
}

export default function RangeCalendar({ startDate, endDate, onSelect }) {
  const days = useMemo(() => {
    const start = new Date();
    return Array.from({ length: 21 }).map((_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const key = iso(d);
      const inRange = startDate && endDate && key >= startDate && key <= endDate;
      const isStart = key === startDate;
      const isEnd = key === endDate;
      return { key, label: d.toLocaleDateString('en-IN', { weekday: 'short' }), day: d.getDate(), month: d.toLocaleDateString('en-IN', { month: 'short' }), inRange, isStart, isEnd };
    });
  }, [startDate, endDate]);

  return (
    <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
      {days.map((day) => (
        <button
          key={day.key}
          type="button"
          onClick={() => onSelect(day.key)}
          className={`rounded-2xl border px-3 py-3 text-left ${day.isStart || day.isEnd ? 'border-brand-500 bg-brand-500 text-white' : day.inRange ? 'border-brand-500/20 bg-brand-500/10 text-brand-200' : 'border-slate-800 bg-slate-900 text-slate-300'}`}
        >
          <div className="text-xs uppercase tracking-wide opacity-80">{day.label}</div>
          <div className="mt-2 text-xl font-bold">{day.day}</div>
          <div className="text-xs opacity-80">{day.month}</div>
        </button>
      ))}
    </div>
  );
}
