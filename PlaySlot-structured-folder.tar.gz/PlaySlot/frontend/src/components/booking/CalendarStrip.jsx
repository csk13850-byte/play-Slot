import { useMemo } from 'react';

function formatKey(date) {
  return date.toISOString().slice(0, 10);
}

export default function CalendarStrip({ selectedDate, onSelect, blockedDates = [], days = 14 }) {
  const items = useMemo(() => {
    const today = new Date();
    return Array.from({ length: days }).map((_, index) => {
      const date = new Date(today);
      date.setDate(today.getDate() + index);
      const key = formatKey(date);
      return {
        key,
        label: date.toLocaleDateString('en-IN', { weekday: 'short' }),
        day: date.toLocaleDateString('en-IN', { day: '2-digit' }),
        month: date.toLocaleDateString('en-IN', { month: 'short' }),
        blocked: blockedDates.includes(key)
      };
    });
  }, [blockedDates, days]);

  return (
    <div className="-mx-1 flex gap-3 overflow-x-auto px-1 pb-1 snap-x snap-mandatory">
      {items.map((item) => {
        const active = selectedDate === item.key;
        return (
          <button
            key={item.key}
            type="button"
            disabled={item.blocked}
            onClick={() => onSelect(item.key)}
            className={`min-w-[84px] snap-start rounded-2xl border px-3 py-3 text-left transition ${active ? 'border-brand-500 bg-brand-500 text-white shadow-lg shadow-brand-500/20' : item.blocked ? 'border-slate-800 bg-slate-900 text-slate-600' : 'border-slate-800 bg-slate-900 text-slate-200 active:scale-[0.98]'}`}
          >
            <p className="text-xs uppercase tracking-wide opacity-80">{item.label}</p>
            <p className="mt-2 text-2xl font-bold leading-none">{item.day}</p>
            <p className="mt-1 text-xs opacity-80">{item.month}</p>
          </button>
        );
      })}
    </div>
  );
}
