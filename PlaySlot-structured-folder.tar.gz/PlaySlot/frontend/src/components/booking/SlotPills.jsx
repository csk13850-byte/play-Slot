export default function SlotPills({ options, value, onChange }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {options.map((option) => {
        const active = value === option.value;
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={`rounded-2xl border px-3 py-3 text-sm font-medium transition ${active ? 'border-brand-500 bg-brand-500/15 text-brand-300' : 'border-slate-800 bg-slate-900 text-slate-300 active:scale-[0.98]'}`}
          >
            <div>{option.label}</div>
            {option.caption ? <div className="mt-1 text-xs text-slate-500">{option.caption}</div> : null}
          </button>
        );
      })}
    </div>
  );
}
