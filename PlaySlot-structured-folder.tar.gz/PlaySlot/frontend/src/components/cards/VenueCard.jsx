import { Link } from 'react-router-dom';

export default function VenueCard({ venue }) {
  return (
    <div className="card overflow-hidden">
      <img src={venue.images?.[0] || 'https://picsum.photos/600/400'} alt={venue.name} className="mb-4 h-44 w-full rounded-xl object-cover" />
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">{venue.name}</h3>
          <p className="text-sm text-slate-400">{venue.location?.area}, {venue.location?.city}</p>
        </div>
        <span className="rounded-full bg-brand-500/15 px-3 py-1 text-xs text-brand-400">From ₹{venue.startingPrice || 0}</span>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {venue.sportsSupported?.slice(0, 3).map((sport) => <span key={sport} className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-300">{sport}</span>)}
      </div>
      <div className="mt-4 flex items-center justify-between text-sm text-slate-400">
        <span>{venue.unitsSummary?.grounds || 0} grounds · {venue.unitsSummary?.turfs || 0} turfs</span>
        <Link className="text-brand-400" to={`/venues/${venue.slug}`}>View details</Link>
      </div>
    </div>
  );
}
