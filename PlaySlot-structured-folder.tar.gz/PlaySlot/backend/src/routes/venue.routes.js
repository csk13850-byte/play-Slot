const router = require('express').Router();
const controller = require('../controllers/venue.controller');
router.get('/', controller.listVenues);
router.get('/search', controller.listVenues);
router.get('/:slug', controller.getVenueBySlug);
router.get('/availability/by-unit', controller.getAvailability);
module.exports = router;
