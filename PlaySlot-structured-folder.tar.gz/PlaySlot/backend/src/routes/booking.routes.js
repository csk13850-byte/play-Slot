const router = require('express').Router();
const controller = require('../controllers/booking.controller');
const { auth } = require('../middleware/auth');

router.post('/quote', auth, controller.quote);
router.post('/hold', auth, controller.createHold);
router.post('/', auth, controller.create);
router.get('/my', auth, controller.myBookings);

module.exports = router;
