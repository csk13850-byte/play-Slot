const router = require('express').Router();
const upload = require('../config/upload');
const controller = require('../controllers/upload.controller');
const { auth, requireOwner } = require('../middleware/auth');
router.post('/images', auth, requireOwner, upload.array('images', 8), controller.uploadImages);
module.exports = router;
