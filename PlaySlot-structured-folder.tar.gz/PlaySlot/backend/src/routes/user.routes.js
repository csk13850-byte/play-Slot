const router = require('express').Router();
const favoriteController = require('../controllers/favorite.controller');
const bookingController = require('../controllers/booking.controller');
const { auth } = require('../middleware/auth');
router.get('/me/bookings', auth, bookingController.myBookings);
router.get('/me/favorites', auth, favoriteController.listFavorites);
router.post('/me/favorites/:venueId', auth, favoriteController.addFavorite);
router.delete('/me/favorites/:venueId', auth, favoriteController.removeFavorite);
module.exports = router;
