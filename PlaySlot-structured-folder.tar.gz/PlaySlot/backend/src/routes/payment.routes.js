const router = require('express').Router();
const controller = require('../controllers/payment.controller');
const { auth } = require('../middleware/auth');
router.post('/dummy/:bookingId', auth, controller.payDummy);
router.post('/stripe/checkout', auth, controller.createStripeCheckout);
router.post('/stripe/confirm', auth, controller.confirmHoldAfterStripe);
module.exports = router;
