const express = require('express');
require('./models/BookingHold');
const cors = require('cors');
const path = require('path');
const authRoutes = require('./routes/auth.routes');
const venueRoutes = require('./routes/venue.routes');
const ownerRoutes = require('./routes/owner.routes');
const bookingRoutes = require('./routes/booking.routes');
const paymentRoutes = require('./routes/payment.routes');
const userRoutes = require('./routes/user.routes');
const uploadRoutes = require('./routes/upload.routes');

const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

app.get('/api/health', (req, res) => res.json({ success: true, message: 'PlaySlot API running' }));
app.use('/api/auth', authRoutes);
app.use('/api/venues', venueRoutes);
app.use('/api/owner', ownerRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/users', userRoutes);
app.use('/api/uploads', uploadRoutes);

module.exports = app;
