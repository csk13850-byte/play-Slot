const Unit = require('../models/Unit');
const Booking = require('../models/Booking');
const AvailabilityRule = require('../models/AvailabilityRule');
const { validateUnitPayload } = require('../utils/validators');

exports.createUnit = async (req, res) => {
  try {
    const errors = validateUnitPayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
    const unit = await Unit.create({ ...req.body, ownerId: req.user._id });
    res.json({ success: true, message: 'Unit created', data: unit });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
};

exports.updateUnit = async (req, res) => {
  const unit = await Unit.findOneAndUpdate({ _id: req.params.id, ownerId: req.user._id }, req.body, { new: true });
  if (!unit) return res.status(404).json({ success: false, message: 'Unit not found' });
  res.json({ success: true, message: 'Unit updated', data: unit });
};

exports.blockAvailability = async (req, res) => {
  const rule = await AvailabilityRule.create({ ...req.body, ownerId: req.user._id });
  res.json({ success: true, message: 'Availability blocked', data: rule });
};

exports.getOwnerBookings = async (req, res) => {
  const bookings = await Booking.find({ ownerId: req.user._id }).populate('venueId unitId userId');
  res.json({ success: true, data: bookings });
};
