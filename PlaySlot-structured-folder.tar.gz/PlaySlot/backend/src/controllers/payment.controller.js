const stripe = process.env.STRIPE_SECRET_KEY ? require('stripe')(process.env.STRIPE_SECRET_KEY) : null;
const Booking = require('../models/Booking');
const BookingHold = require('../models/BookingHold');
const Payment = require('../models/Payment');
const { createBookingFromHold } = require('../services/booking.service');

exports.payDummy = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.bookingId);
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
    booking.paymentStatus = 'paid';
    booking.status = 'confirmed';
    await booking.save();
    await Payment.findOneAndUpdate({ bookingId: booking._id }, { status: 'paid', provider: 'dummy' }, { new: true });
    return res.json({ success: true, message: 'Dummy payment successful', data: booking });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

exports.createStripeCheckout = async (req, res) => {
  try {
    if (!stripe) return res.status(400).json({ success: false, message: 'Stripe is not configured. Use dummy payment or add STRIPE_SECRET_KEY.' });
    const hold = await BookingHold.findOne({ _id: req.body.holdId, userId: req.user._id, status: 'active', expiresAt: { $gt: new Date() } }).populate('unitId venueId');
    if (!hold) return res.status(404).json({ success: false, message: 'Active hold not found' });
    const origin = process.env.FRONTEND_URL || 'http://localhost:5173';
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        quantity: 1,
        price_data: {
          currency: 'inr',
          unit_amount: Math.round(Number(hold.totalAmount) * 100),
          product_data: { name: `${hold.venueId.name} - ${hold.unitId.name}` }
        }
      }],
      success_url: `${origin}/payment/success?holdId=${hold._id}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/payment/cancel?holdId=${hold._id}`
    });
    await Payment.create({ amount: hold.totalAmount, status: 'pending', provider: 'stripe', providerSessionId: session.id });
    return res.json({ success: true, data: { url: session.url, sessionId: session.id } });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};

exports.confirmHoldAfterStripe = async (req, res) => {
  try {
    const booking = await createBookingFromHold(req.body.holdId, req.user);
    booking.paymentStatus = 'paid';
    booking.status = 'confirmed';
    await booking.save();
    await Payment.findOneAndUpdate({ providerSessionId: req.body.sessionId }, { bookingId: booking._id, status: 'paid' }, { new: true });
    return res.json({ success: true, message: 'Stripe payment confirmed', data: booking });
  } catch (error) {
    return res.status(400).json({ success: false, message: error.message });
  }
};
