const bcrypt = require('bcryptjs');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');

exports.register = async (req, res) => {
  try {
    const { name, email, password, role, phone } = req.body;
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ success: false, message: 'Email already exists' });
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, passwordHash, role: role || 'user', phone, isOwnerEnabled: role === 'owner' });
    const token = generateToken(user);
    res.json({ success: true, message: 'Account created', data: { token, user } });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ success: false, message: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(400).json({ success: false, message: 'Invalid credentials' });
    const token = generateToken(user);
    res.json({ success: true, message: 'Login successful', data: { token, user } });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
};

exports.me = async (req, res) => {
  res.json({ success: true, data: req.user });
};
