const Favorite = require('../models/Favorite');
const Venue = require('../models/Venue');

exports.listFavorites = async (req, res) => {
  const favorites = await Favorite.find({ userId: req.user._id }).populate('venueId');
  res.json({ success: true, data: favorites });
};

exports.addFavorite = async (req, res) => {
  const venue = await Venue.findById(req.params.venueId);
  if (!venue) return res.status(404).json({ success: false, message: 'Venue not found' });
  const favorite = await Favorite.findOneAndUpdate({ userId: req.user._id, venueId: venue._id }, {}, { upsert: true, new: true });
  res.json({ success: true, message: 'Favorite added', data: favorite });
};

exports.removeFavorite = async (req, res) => {
  await Favorite.findOneAndDelete({ userId: req.user._id, venueId: req.params.venueId });
  res.json({ success: true, message: 'Favorite removed' });
};
