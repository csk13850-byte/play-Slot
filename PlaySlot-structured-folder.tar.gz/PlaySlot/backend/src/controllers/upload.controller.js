exports.uploadImages = async (req, res) => {
  const files = req.files || [];
  const urls = files.map((file) => `/uploads/${file.filename}`);
  res.json({ success: true, message: 'Images uploaded successfully', data: { files: urls } });
};
