const Booking = require('../models/Booking');
const BookingHold = require('../models/BookingHold');
const { quoteBooking, createBooking, createHold } = require('../services/booking.service');
const { validateBookingPayload } = require('../utils/validators');

exports.quote = async (req, res) => {
  try {
    const errors = validateBookingPayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
    const result = await quoteBooking(req.body);
    res.json({ success: true, data: { totalAmount: result.totalAmount } });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

exports.create = async (req, res) => {
  try {
    const errors = validateBookingPayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
    const booking = await createBooking(req.body, req.user);
    res.status(201).json({ success: true, message: 'Booking created successfully', data: booking });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

exports.createHold = async (req, res) => {
  try {
    const errors = validateBookingPayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
    const hold = await createHold(req.body, req.user);
    res.status(201).json({ success: true, message: 'Booking hold created', data: hold });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

exports.myBookings = async (req, res) => {
  const bookings = await Booking.find({ userId: req.user._id }).populate('venueId unitId').sort({ createdAt: -1 });
  const holds = await BookingHold.find({ userId: req.user._id, status: 'active', expiresAt: { $gt: new Date() } }).populate('venueId unitId').sort({ createdAt: -1 });
  res.json({ success: true, data: { bookings, holds } });
};
