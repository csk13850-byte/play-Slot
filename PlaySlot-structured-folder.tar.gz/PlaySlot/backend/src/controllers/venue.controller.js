const slugify = require('slugify');
const Venue = require('../models/Venue');
const Unit = require('../models/Unit');
const Booking = require('../models/Booking');
const AvailabilityRule = require('../models/AvailabilityRule');
const { validateVenuePayload } = require('../utils/validators');

exports.listVenues = async (req, res) => {
  const { location, sport, unitType, minPrice, maxPrice } = req.query;
  let venues = await Venue.find({ isActive: true }).lean();
  const units = await Unit.find({ isActive: true }).lean();

  const unitMap = units.reduce((acc, unit) => {
    const key = String(unit.venueId);
    acc[key] = acc[key] || [];
    acc[key].push(unit);
    return acc;
  }, {});

  venues = venues.filter((venue) => {
    const venueUnits = unitMap[String(venue._id)] || [];
    if (location && !(venue.location?.city || '').toLowerCase().includes(location.toLowerCase()) && !(venue.location?.area || '').toLowerCase().includes(location.toLowerCase())) return false;
    if (sport && !venue.sportsSupported?.includes(sport)) return false;
    if (unitType && !venueUnits.some((u) => u.unitType === unitType)) return false;
    if (minPrice || maxPrice) {
      const prices = venueUnits.flatMap((u) => Object.values(u.pricing || {}).filter(Boolean));
      const starting = prices.length ? Math.min(...prices) : 0;
      if (minPrice && starting < Number(minPrice)) return false;
      if (maxPrice && starting > Number(maxPrice)) return false;
    }
    return true;
  }).map((venue) => {
    const venueUnits = unitMap[String(venue._id)] || [];
    const prices = venueUnits.flatMap((u) => Object.values(u.pricing || {}).filter(Boolean));
    return {
      ...venue,
      startingPrice: prices.length ? Math.min(...prices) : 0,
      unitsSummary: {
        grounds: venueUnits.filter((u) => u.unitType === 'ground').length,
        turfs: venueUnits.filter((u) => u.unitType === 'turf').length
      }
    };
  });

  res.json({ success: true, data: { items: venues, pagination: { page: 1, limit: venues.length, total: venues.length } } });
};

exports.getVenueBySlug = async (req, res) => {
  const venue = await Venue.findOne({ slug: req.params.slug }).lean();
  if (!venue) return res.status(404).json({ success: false, message: 'Venue not found' });
  const units = await Unit.find({ venueId: venue._id }).lean();
  res.json({ success: true, data: { ...venue, units } });
};

exports.getAvailability = async (req, res) => {
  const { unitId, month, date } = req.query;
  const unit = await Unit.findById(unitId).lean();
  if (!unit) return res.status(404).json({ success: false, message: 'Unit not found' });
  const bookings = await Booking.find({ unitId }).lean();
  const blocks = await AvailabilityRule.find({ unitId }).lean();
  let hourlySlots = [];
  if (unit.unitType === 'turf' && date) {
    const start = Number(unit.slotConfig.turfStartHour.split(':')[0]);
    const end = Number(unit.slotConfig.turfEndHour.split(':')[0]);
    for (let h = start; h < end; h++) {
      const startTime = `${String(h).padStart(2,'0')}:00`;
      const endTime = `${String(h+1).padStart(2,'0')}:00`;
      const booked = bookings.some((b) => b.date === date && b.bookingType === 'turf' && startTime < b.endTime && endTime > b.startTime);
      hourlySlots.push({ startTime, endTime, available: !booked });
    }
  }
  res.json({ success: true, data: { unit, month, date, bookings, blocks, hourlySlots } });
};

exports.createVenue = async (req, res) => {
  try {
    const errors = validateVenuePayload(req.body);
    if (errors.length) return res.status(400).json({ success: false, message: 'Validation failed', errors });
    const slug = slugify(req.body.name, { lower: true, strict: true });
    const venue = await Venue.create({ ...req.body, slug, ownerId: req.user._id });
    res.json({ success: true, message: 'Venue created', data: venue });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
};

exports.updateVenue = async (req, res) => {
  const venue = await Venue.findOneAndUpdate({ _id: req.params.id, ownerId: req.user._id }, req.body, { new: true });
  if (!venue) return res.status(404).json({ success: false, message: 'Venue not found' });
  res.json({ success: true, message: 'Venue updated', data: venue });
};

exports.ownerVenues = async (req, res) => {
  const venues = await Venue.find({ ownerId: req.user._id });
  res.json({ success: true, data: venues });
};
