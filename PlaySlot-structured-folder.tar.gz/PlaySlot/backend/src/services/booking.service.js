const mongoose = require('mongoose');
const Booking = require('../models/Booking');
const BookingHold = require('../models/BookingHold');
const Unit = require('../models/Unit');
const Venue = require('../models/Venue');
const AvailabilityRule = require('../models/AvailabilityRule');
const Payment = require('../models/Payment');
const generateBookingNumber = require('../utils/generateBookingNumber');
const { enumerateDates, addHours, isRangeOverlapping, overlapsTime } = require('../utils/date');

const ACTIVE_BOOKING_STATUSES = ['pending', 'confirmed'];
const ACTIVE_HOLD_STATUSES = ['active'];

function calculateTotal(payload, unit) {
  if (payload.bookingType === 'tournament') {
    const dates = enumerateDates(payload.startDate, payload.endDate);
    return dates.length * Number(unit.pricing.full || unit.pricing.day || 0);
  }
  if (payload.bookingType === 'ground') {
    return Number(unit.pricing[payload.slotType] || 0);
  }
  return Number(unit.pricing.hourly || 0) * Number(payload.hours || 1);
}

async function assertNoConflict(payload, unit, session = null) {
  const query = { unitId: unit._id, status: { $in: ACTIVE_BOOKING_STATUSES } };
  const bookings = await Booking.find(query).session(session);
  const holds = await BookingHold.find({ unitId: unit._id, status: { $in: ACTIVE_HOLD_STATUSES }, expiresAt: { $gt: new Date() } }).session(session);
  const blocks = await AvailabilityRule.find({ unitId: unit._id }).session(session);

  const incoming = normalizeWindow(payload);
  for (const item of [...bookings, ...holds]) {
    if (windowsConflict(incoming, normalizeWindow(item))) throw new Error('Selected slot is no longer available');
  }
  for (const rule of blocks) {
    if (rule.ruleType === 'blocked_date' && incoming.dates.includes(rule.date)) throw new Error('Selected date is blocked by owner');
    if (rule.ruleType === 'blocked_slot' && rule.date && incoming.dates.includes(rule.date)) {
      const blocked = normalizeWindow(rule);
      if (windowsConflict(incoming, blocked)) throw new Error('Selected slot is blocked by owner');
    }
  }
}

function normalizeWindow(payload) {
  if (payload.bookingType === 'tournament' || payload.startDate) {
    return { mode: 'range', slotType: payload.slotType, startDate: payload.startDate, endDate: payload.endDate, dates: enumerateDates(payload.startDate, payload.endDate) };
  }
  if (payload.bookingType === 'turf' || payload.slotType === 'hourly') {
    return { mode: 'hourly', slotType: 'hourly', date: payload.date, startTime: payload.startTime, endTime: payload.endTime || addHours(payload.startTime, Number(payload.hours || 1)), dates: [payload.date] };
  }
  return { mode: 'slot', slotType: payload.slotType, date: payload.date, dates: [payload.date] };
}

function windowsConflict(a, b) {
  if (a.mode === 'range' || b.mode === 'range') {
    const aStart = a.startDate || a.date;
    const aEnd = a.endDate || a.date;
    const bStart = b.startDate || b.date;
    const bEnd = b.endDate || b.date;
    return isRangeOverlapping(aStart, aEnd, bStart, bEnd);
  }
  if (a.date !== b.date) return false;
  if (a.mode === 'hourly' && b.mode === 'hourly') return overlapsTime(a.startTime, a.endTime, b.startTime, b.endTime);
  if (a.slotType === 'full' || b.slotType === 'full') return true;
  return a.slotType === b.slotType;
}

async function quoteBooking(payload) {
  const unit = await Unit.findById(payload.unitId);
  if (!unit) throw new Error('Unit not found');
  await assertNoConflict(payload, unit);
  const totalAmount = calculateTotal(payload, unit);
  return { totalAmount, unit };
}

async function createHold(payload, user) {
  const unit = await Unit.findById(payload.unitId);
  if (!unit) throw new Error('Unit not found');
  const venue = await Venue.findById(unit.venueId);
  const totalAmount = calculateTotal(payload, unit);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  await mongoose.connection.transaction(async (session) => {
    await assertNoConflict(payload, unit, session);
    await BookingHold.create([{ ...payload, venueId: venue._id, userId: user._id, totalAmount, endTime: payload.endTime || (payload.bookingType === 'turf' ? addHours(payload.startTime, Number(payload.hours || 1)) : undefined), expiresAt }], { session });
  });

  const hold = await BookingHold.findOne({ userId: user._id, unitId: unit._id, status: 'active' }).sort({ createdAt: -1 });
  return hold;
}

async function createBookingFromHold(holdId, user) {
  let bookingDoc;
  await mongoose.connection.transaction(async (session) => {
    const hold = await BookingHold.findOne({ _id: holdId, userId: user._id, status: 'active', expiresAt: { $gt: new Date() } }).session(session);
    if (!hold) throw new Error('Booking hold expired or not found');
    const unit = await Unit.findById(hold.unitId).session(session);
    await assertNoConflict(hold, unit, session);
    const bookingNumber = await generateBookingNumber();
    const [booking] = await Booking.create([{ ...hold.toObject(), _id: undefined, bookingNumber, paymentStatus: 'pending', status: 'pending' }], { session });
    await Payment.create([{ bookingId: booking._id, amount: hold.totalAmount, status: 'pending', provider: 'dummy' }], { session });
    hold.status = 'converted';
    await hold.save({ session });
    bookingDoc = booking;
  });
  return bookingDoc;
}

async function createBooking(payload, user) {
  const hold = await createHold(payload, user);
  return createBookingFromHold(hold._id, user);
}

module.exports = { quoteBooking, createBooking, createHold, createBookingFromHold };
