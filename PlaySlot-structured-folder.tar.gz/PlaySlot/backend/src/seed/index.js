require('dotenv').config({ path: require('path').join(__dirname, '../../.env') });
const bcrypt = require('bcryptjs');
const connectDB = require('../config/db');
const User = require('../models/User');
const Venue = require('../models/Venue');
const Unit = require('../models/Unit');
const Booking = require('../models/Booking');
const Favorite = require('../models/Favorite');
const generateBookingNumber = require('../utils/generateBookingNumber');
const slugify = require('slugify');

async function run() {
  await connectDB(process.env.MONGODB_URI);
  await Promise.all([User.deleteMany({}), Venue.deleteMany({}), Unit.deleteMany({}), Booking.deleteMany({}), Favorite.deleteMany({})]);
  const passwordHash = await bcrypt.hash('password123', 10);
  const owner1 = await User.create({ name: 'Owner One', email: 'owner1@playslot.com', passwordHash, role: 'owner', isOwnerEnabled: true });
  const owner2 = await User.create({ name: 'Owner Two', email: 'owner2@playslot.com', passwordHash, role: 'owner', isOwnerEnabled: true });
  const user1 = await User.create({ name: 'User One', email: 'user1@playslot.com', passwordHash, role: 'user' });

  const venueData = [
    { ownerId: owner1._id, name: 'Nashik Premier Arena', description: 'Cricket-first sports venue with ground and turf options.', sportsSupported: ['cricket','football'], location: { city: 'Nashik', area: 'Gangapur Road', address: 'Near Gangapur Road, Nashik' }, amenities: ['Floodlights','Parking','Washrooms','Drinking Water'], services: { equipment: ['bat','ball','stumps'], umpire: true, scorer: true, pickDrop: false, liveStreaming: true }, images: ['https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=1200&auto=format&fit=crop'] },
    { ownerId: owner2._id, name: 'Victory Box Turf', description: 'Evening-friendly turf venue for cricket and football.', sportsSupported: ['cricket','football','badminton'], location: { city: 'Nashik', area: 'College Road', address: 'College Road, Nashik' }, amenities: ['Floodlights','Parking','Seating'], services: { equipment: ['ball'], umpire: false, scorer: false, pickDrop: false, liveStreaming: false }, images: ['https://images.unsplash.com/photo-1518604666860-9ed391f76460?q=80&w=1200&auto=format&fit=crop'] }
  ];

  const venues = [];
  for (const item of venueData) {
    venues.push(await Venue.create({ ...item, slug: slugify(item.name, { lower: true, strict: true }) }));
  }

  const ground1 = await Unit.create({ venueId: venues[0]._id, ownerId: owner1._id, name: 'Main Ground', unitType: 'ground', sportsSupported: ['cricket'], pricing: { day: 5000, night: 6500, full: 10000 }, slotConfig: { dayStart: '06:00', dayEnd: '18:00', slotDurationMinutes: 60 } });
  const turf1 = await Unit.create({ venueId: venues[0]._id, ownerId: owner1._id, name: 'Practice Turf 1', unitType: 'turf', sportsSupported: ['cricket'], pricing: { hourly: 900 }, slotConfig: { turfStartHour: '06:00', turfEndHour: '23:00', slotDurationMinutes: 60 } });
  const turf2 = await Unit.create({ venueId: venues[1]._id, ownerId: owner2._id, name: 'Box Turf A', unitType: 'turf', sportsSupported: ['cricket','football'], pricing: { hourly: 1100 }, slotConfig: { turfStartHour: '07:00', turfEndHour: '22:00', slotDurationMinutes: 60 } });
  const ground2 = await Unit.create({ venueId: venues[1]._id, ownerId: owner2._id, name: 'Open Match Ground', unitType: 'ground', sportsSupported: ['football','cricket'], pricing: { day: 4200, night: 5600, full: 8500 }, slotConfig: { dayStart: '06:00', dayEnd: '18:00', slotDurationMinutes: 60 } });

  await Booking.create({ bookingNumber: generateBookingNumber(), userId: user1._id, ownerId: owner1._id, venueId: venues[0]._id, unitId: ground1._id, bookingType: 'ground', slotType: 'day', date: '2026-04-20', totalAmount: 5000, paymentStatus: 'paid', bookingStatus: 'confirmed', contactName: 'User One', contactPhone: '9999999999' });
  await Booking.create({ bookingNumber: generateBookingNumber(), userId: user1._id, ownerId: owner1._id, venueId: venues[0]._id, unitId: turf1._id, bookingType: 'turf', slotType: 'hourly', date: '2026-04-20', startTime: '18:00', endTime: '20:00', hours: 2, totalAmount: 1800, paymentStatus: 'paid', bookingStatus: 'confirmed', contactName: 'User One', contactPhone: '9999999999' });
  await Booking.create({ bookingNumber: generateBookingNumber(), userId: user1._id, ownerId: owner2._id, venueId: venues[1]._id, unitId: ground2._id, bookingType: 'tournament', slotType: 'full', startDate: '2026-04-25', endDate: '2026-04-27', totalAmount: 25500, paymentStatus: 'pending', bookingStatus: 'confirmed', contactName: 'User One', contactPhone: '9999999999' });
  console.log('Seed complete');
  process.exit(0);
}

run().catch((e) => { console.error(e); process.exit(1); });
