const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  bookingId: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  amount: Number,
  currency: { type: String, default: 'INR' },
  method: { type: String, default: 'dummy' },
  status: { type: String, default: 'paid' },
  transactionRef: String
}, { timestamps: true });

module.exports = mongoose.model('Payment', paymentSchema);
