const mongoose = require('mongoose');
const { BOOKING_TYPES, SLOT_TYPES, BOOKING_STATUS, PAYMENT_STATUS } = require('../../../shared/enums');

const bookingSchema = new mongoose.Schema({
  bookingNumber: { type: String, unique: true, required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  venueId: { type: mongoose.Schema.Types.ObjectId, ref: 'Venue', required: true },
  unitId: { type: mongoose.Schema.Types.ObjectId, ref: 'Unit', required: true },
  bookingType: { type: String, enum: BOOKING_TYPES, required: true },
  slotType: { type: String, enum: SLOT_TYPES, required: true },
  date: String,
  startDate: String,
  endDate: String,
  startTime: String,
  endTime: String,
  hours: Number,
  priceBreakdown: { type: Object, default: {} },
  totalAmount: { type: Number, required: true },
  paymentStatus: { type: String, enum: PAYMENT_STATUS, default: 'pending' },
  bookingStatus: { type: String, enum: BOOKING_STATUS, default: 'confirmed' },
  contactName: String,
  contactPhone: String
}, { timestamps: true });

module.exports = mongoose.model('Booking', bookingSchema);
