const mongoose = require('mongoose');
const { ROLES } = require('../../../shared/enums');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ROLES, default: 'user' },
  phone: String,
  isOwnerEnabled: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
