const mongoose = require('mongoose');

const bookingHoldSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    venueId: { type: mongoose.Schema.Types.ObjectId, ref: 'Venue', required: true },
    unitId: { type: mongoose.Schema.Types.ObjectId, ref: 'Unit', required: true },
    bookingType: { type: String, enum: ['ground', 'turf', 'tournament'], required: true },
    slotType: { type: String, enum: ['day', 'night', 'hourly', 'full'], required: true },
    date: String,
    startDate: String,
    endDate: String,
    startTime: String,
    endTime: String,
    hours: Number,
    contactName: String,
    contactPhone: String,
    totalAmount: { type: Number, required: true },
    expiresAt: { type: Date, required: true, index: { expireAfterSeconds: 0 } },
    status: { type: String, enum: ['active', 'converted', 'expired', 'cancelled'], default: 'active' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('BookingHold', bookingHoldSchema);
