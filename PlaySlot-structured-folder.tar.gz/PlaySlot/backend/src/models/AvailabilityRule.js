const mongoose = require('mongoose');
const { RULE_TYPES } = require('../../../shared/enums');

const availabilityRuleSchema = new mongoose.Schema({
  unitId: { type: mongoose.Schema.Types.ObjectId, ref: 'Unit', required: true },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  ruleType: { type: String, enum: RULE_TYPES, required: true },
  daysOfWeek: [Number],
  date: String,
  startTime: String,
  endTime: String,
  slotType: String,
  reason: String
}, { timestamps: true });

module.exports = mongoose.model('AvailabilityRule', availabilityRuleSchema);
