const mongoose = require('mongoose');

const venueSchema = new mongoose.Schema({
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  description: String,
  sportsSupported: [String],
  location: {
    city: String,
    area: String,
    address: String,
    lat: Number,
    lng: Number
  },
  amenities: [String],
  services: {
    equipment: [String],
    pickDrop: { type: Boolean, default: false },
    umpire: { type: Boolean, default: false },
    scorer: { type: Boolean, default: false },
    liveStreaming: { type: Boolean, default: false }
  },
  images: [String],
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Venue', venueSchema);
