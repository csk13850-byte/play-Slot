const mongoose = require('mongoose');
const { UNIT_TYPES } = require('../../../shared/enums');

const unitSchema = new mongoose.Schema({
  venueId: { type: mongoose.Schema.Types.ObjectId, ref: 'Venue', required: true },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  unitType: { type: String, enum: UNIT_TYPES, required: true },
  sportsSupported: [String],
  pricing: {
    hourly: Number,
    day: Number,
    night: Number,
    full: Number
  },
  slotConfig: {
    dayStart: { type: String, default: '06:00' },
    dayEnd: { type: String, default: '18:00' },
    slotDurationMinutes: { type: Number, default: 60 },
    turfStartHour: { type: String, default: '06:00' },
    turfEndHour: { type: String, default: '23:00' }
  },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Unit', unitSchema);
