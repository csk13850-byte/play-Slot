function isValidDateString(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value || '');
}

function isValidTimeString(value) {
  return /^\d{2}:\d{2}$/.test(value || '');
}

function timeToMinutes(value) {
  const [h, m] = String(value).split(':').map(Number);
  return h * 60 + m;
}

function validateBookingPayload(payload) {
  const errors = [];
  if (!payload.unitId) errors.push('Unit is required');
  if (!payload.bookingType) errors.push('Booking type is required');
  if (!payload.slotType) errors.push('Slot type is required');
  if (!payload.contactName) errors.push('Contact name is required');
  if (!payload.contactPhone) errors.push('Contact phone is required');

  if (payload.bookingType === 'ground') {
    if (!isValidDateString(payload.date)) errors.push('Valid booking date is required');
    if (!['day', 'night', 'full'].includes(payload.slotType)) errors.push('Ground slot must be day, night, or full');
  }

  if (payload.bookingType === 'tournament') {
    if (!isValidDateString(payload.startDate) || !isValidDateString(payload.endDate)) errors.push('Valid tournament start and end dates are required');
    if (payload.startDate && payload.endDate && payload.startDate > payload.endDate) errors.push('Tournament end date must be after start date');
    if (!['day', 'night', 'full'].includes(payload.slotType)) errors.push('Tournament slot must be day, night, or full');
  }

  if (payload.bookingType === 'turf') {
    if (!isValidDateString(payload.date)) errors.push('Valid turf booking date is required');
    if (!isValidTimeString(payload.startTime)) errors.push('Valid turf start time is required');
    const hours = Number(payload.hours);
    if (!Number.isInteger(hours) || hours < 1 || hours > 8) errors.push('Turf booking hours must be between 1 and 8');
    if (payload.slotType !== 'hourly') errors.push('Turf slot type must be hourly');
  }

  return errors;
}

function validateVenuePayload(payload) {
  const errors = [];
  if (!payload.name || payload.name.trim().length < 3) errors.push('Venue name must be at least 3 characters');
  if (!payload.description || payload.description.trim().length < 20) errors.push('Venue description must be at least 20 characters');
  if (!payload.location?.city) errors.push('City is required');
  if (!Array.isArray(payload.sportsSupported) || payload.sportsSupported.length === 0) errors.push('At least one sport is required');
  return errors;
}

function validateUnitPayload(payload) {
  const errors = [];
  if (!payload.venueId) errors.push('Venue is required');
  if (!payload.name || payload.name.trim().length < 2) errors.push('Unit name is required');
  if (!['ground', 'turf'].includes(payload.unitType)) errors.push('Unit type must be ground or turf');
  if (!Array.isArray(payload.sportsSupported) || payload.sportsSupported.length === 0) errors.push('At least one sport is required');
  if (payload.unitType === 'ground') {
    if (!payload.pricing?.day || !payload.pricing?.night || !payload.pricing?.full) errors.push('Ground pricing must include day, night, and full');
  }
  if (payload.unitType === 'turf') {
    if (!payload.pricing?.hourly) errors.push('Turf pricing must include hourly');
    if (!payload.slotConfig?.turfStartHour || !payload.slotConfig?.turfEndHour) errors.push('Turf operating hours are required');
    if (payload.slotConfig?.turfStartHour && payload.slotConfig?.turfEndHour && timeToMinutes(payload.slotConfig.turfStartHour) >= timeToMinutes(payload.slotConfig.turfEndHour)) {
      errors.push('Turf end time must be after start time');
    }
  }
  return errors;
}

module.exports = { validateBookingPayload, validateVenuePayload, validateUnitPayload, isValidDateString, isValidTimeString, timeToMinutes };
