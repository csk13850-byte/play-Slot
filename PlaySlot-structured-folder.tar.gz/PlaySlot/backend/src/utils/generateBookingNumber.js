module.exports = function generateBookingNumber() {
  const now = new Date();
  const stamp = now.toISOString().slice(0,10).replace(/-/g,'');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `PS-${stamp}-${rand}`;
};
