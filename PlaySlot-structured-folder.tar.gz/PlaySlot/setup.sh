#!/usr/bin/env bash
set -e
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"

if [ ! -f "$BACKEND_DIR/.env" ]; then
  cp "$ROOT_DIR/.env.example" "$BACKEND_DIR/.env"
fi

cd "$BACKEND_DIR"
npm install

cd "$FRONTEND_DIR"
npm install

cd "$BACKEND_DIR"
node src/seed/index.js >/dev/null 2>&1 || true

cd "$ROOT_DIR"
cleanup() {
  jobs -p | xargs -r kill >/dev/null 2>&1 || true
}
trap cleanup EXIT

(cd "$BACKEND_DIR" && npm run dev) &
(cd "$FRONTEND_DIR" && npm run dev -- --host 0.0.0.0) &
wait
